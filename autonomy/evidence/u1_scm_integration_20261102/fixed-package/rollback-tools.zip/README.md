回滚工具 / Rollback tools

Use release_store.py --root STORE rollback TRANSACTION --expected-current VERSION.
回滚必须同时保留STORE中的backups记录和versions旧版本；此包不是生产状态备份。
Retain both backups and versions; this archive alone is not a state backup. No service or Inventory changes.
